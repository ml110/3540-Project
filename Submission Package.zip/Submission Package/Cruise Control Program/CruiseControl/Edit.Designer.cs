﻿namespace CruiseControl
{
    partial class Edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Edit));
			this.panel2 = new System.Windows.Forms.Panel();
			this.rbcFalse = new System.Windows.Forms.RadioButton();
			this.rbcTrue = new System.Windows.Forms.RadioButton();
			this.label8 = new System.Windows.Forms.Label();
			this.btnEdit = new System.Windows.Forms.Button();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.rbrFalse = new System.Windows.Forms.RadioButton();
			this.rbrTrue = new System.Windows.Forms.RadioButton();
			this.cmbStatus = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.cmbPort = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.txtDay = new System.Windows.Forms.TextBox();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
			this.panel2.SuspendLayout();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.rbcFalse);
			this.panel2.Controls.Add(this.rbcTrue);
			this.panel2.Location = new System.Drawing.Point(119, 218);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(62, 50);
			this.panel2.TabIndex = 53;
			// 
			// rbcFalse
			// 
			this.rbcFalse.AutoSize = true;
			this.rbcFalse.Location = new System.Drawing.Point(3, 27);
			this.rbcFalse.Name = "rbcFalse";
			this.rbcFalse.Size = new System.Drawing.Size(50, 17);
			this.rbcFalse.TabIndex = 1;
			this.rbcFalse.TabStop = true;
			this.rbcFalse.Text = "False";
			this.rbcFalse.UseVisualStyleBackColor = true;
			// 
			// rbcTrue
			// 
			this.rbcTrue.AutoSize = true;
			this.rbcTrue.Checked = true;
			this.rbcTrue.Location = new System.Drawing.Point(3, 4);
			this.rbcTrue.Name = "rbcTrue";
			this.rbcTrue.Size = new System.Drawing.Size(47, 17);
			this.rbcTrue.TabIndex = 0;
			this.rbcTrue.TabStop = true;
			this.rbcTrue.Text = "True";
			this.rbcTrue.UseVisualStyleBackColor = true;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
			this.label8.Location = new System.Drawing.Point(28, 218);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(82, 16);
			this.label8.TabIndex = 60;
			this.label8.Text = "isCancelled:";
			// 
			// btnEdit
			// 
			this.btnEdit.Location = new System.Drawing.Point(6, 343);
			this.btnEdit.Name = "btnEdit";
			this.btnEdit.Size = new System.Drawing.Size(258, 59);
			this.btnEdit.TabIndex = 58;
			this.btnEdit.Text = "Edit Day";
			this.btnEdit.UseVisualStyleBackColor = true;
			this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
			this.label7.Location = new System.Drawing.Point(8, 318);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(105, 16);
			this.label7.TabIndex = 57;
			this.label7.Text = "Departure Time:";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
			this.label6.Location = new System.Drawing.Point(30, 281);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(83, 16);
			this.label6.TabIndex = 56;
			this.label6.Text = "Arrival Time:";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
			this.label5.Location = new System.Drawing.Point(43, 157);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(69, 16);
			this.label5.TabIndex = 52;
			this.label5.Text = "IsReroute:";
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.rbrFalse);
			this.panel1.Controls.Add(this.rbrTrue);
			this.panel1.Location = new System.Drawing.Point(119, 157);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(62, 50);
			this.panel1.TabIndex = 51;
			// 
			// rbrFalse
			// 
			this.rbrFalse.AutoSize = true;
			this.rbrFalse.Location = new System.Drawing.Point(3, 27);
			this.rbrFalse.Name = "rbrFalse";
			this.rbrFalse.Size = new System.Drawing.Size(50, 17);
			this.rbrFalse.TabIndex = 1;
			this.rbrFalse.TabStop = true;
			this.rbrFalse.Text = "False";
			this.rbrFalse.UseVisualStyleBackColor = true;
			// 
			// rbrTrue
			// 
			this.rbrTrue.AutoSize = true;
			this.rbrTrue.Checked = true;
			this.rbrTrue.Location = new System.Drawing.Point(3, 4);
			this.rbrTrue.Name = "rbrTrue";
			this.rbrTrue.Size = new System.Drawing.Size(47, 17);
			this.rbrTrue.TabIndex = 0;
			this.rbrTrue.TabStop = true;
			this.rbrTrue.Text = "True";
			this.rbrTrue.UseVisualStyleBackColor = true;
			// 
			// cmbStatus
			// 
			this.cmbStatus.FormattingEnabled = true;
			this.cmbStatus.Location = new System.Drawing.Point(119, 121);
			this.cmbStatus.Name = "cmbStatus";
			this.cmbStatus.Size = new System.Drawing.Size(121, 21);
			this.cmbStatus.TabIndex = 50;
			this.cmbStatus.SelectedIndexChanged += new System.EventHandler(this.cmbStatus_SelectedIndexChanged);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
			this.label4.Location = new System.Drawing.Point(62, 121);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(48, 16);
			this.label4.TabIndex = 49;
			this.label4.Text = "Status:";
			// 
			// cmbPort
			// 
			this.cmbPort.FormattingEnabled = true;
			this.cmbPort.Location = new System.Drawing.Point(119, 84);
			this.cmbPort.Name = "cmbPort";
			this.cmbPort.Size = new System.Drawing.Size(121, 21);
			this.cmbPort.TabIndex = 48;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
			this.label3.Location = new System.Drawing.Point(74, 85);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(38, 16);
			this.label3.TabIndex = 47;
			this.label3.Text = "Port: ";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
			this.label2.Location = new System.Drawing.Point(70, 47);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(43, 16);
			this.label2.TabIndex = 46;
			this.label2.Text = "Date: ";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
			this.label1.Location = new System.Drawing.Point(74, 12);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(39, 16);
			this.label1.TabIndex = 44;
			this.label1.Text = "Day: ";
			// 
			// txtDay
			// 
			this.txtDay.Enabled = false;
			this.txtDay.Location = new System.Drawing.Point(119, 12);
			this.txtDay.Name = "txtDay";
			this.txtDay.Size = new System.Drawing.Size(100, 20);
			this.txtDay.TabIndex = 43;
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Location = new System.Drawing.Point(119, 47);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(121, 20);
			this.dateTimePicker1.TabIndex = 61;
			// 
			// dateTimePicker2
			// 
			this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePicker2.Location = new System.Drawing.Point(119, 281);
			this.dateTimePicker2.Name = "dateTimePicker2";
			this.dateTimePicker2.ShowUpDown = true;
			this.dateTimePicker2.Size = new System.Drawing.Size(100, 20);
			this.dateTimePicker2.TabIndex = 62;
			// 
			// dateTimePicker3
			// 
			this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePicker3.Location = new System.Drawing.Point(119, 314);
			this.dateTimePicker3.Name = "dateTimePicker3";
			this.dateTimePicker3.ShowUpDown = true;
			this.dateTimePicker3.Size = new System.Drawing.Size(100, 20);
			this.dateTimePicker3.TabIndex = 63;
			// 
			// Edit
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(269, 408);
			this.Controls.Add(this.dateTimePicker3);
			this.Controls.Add(this.dateTimePicker2);
			this.Controls.Add(this.dateTimePicker1);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.btnEdit);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.cmbStatus);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.cmbPort);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtDay);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Edit";
			this.Text = "CRUISE CONTROL: Edit Day";
			this.Load += new System.EventHandler(this.Edit_Load);
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rbcFalse;
        private System.Windows.Forms.RadioButton rbcTrue;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rbrFalse;
        private System.Windows.Forms.RadioButton rbrTrue;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbPort;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDay;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
    }
}