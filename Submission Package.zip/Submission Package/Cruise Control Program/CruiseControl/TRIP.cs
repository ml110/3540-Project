﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CruiseControl
{
    class TRIP
    {
        public int trip_id { get; set; }
        public int ship_id { get; set; }
        public int departure_port { get; set; }
        public DateTime departure_date { get; set; }
        public int destination_date { get; set; }
    }
}
