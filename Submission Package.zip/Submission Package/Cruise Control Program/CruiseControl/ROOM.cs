﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CruiseControl
{
    class ROOM
    {
        public int room_id { get; set; }
        public int room_number { get; set; }
        public int roomCat_id { get; set; }
        public int clearer_id { get; set; }
        public string phone_number { get; set; }
        public int ship_id { get; set; }
    }
}
