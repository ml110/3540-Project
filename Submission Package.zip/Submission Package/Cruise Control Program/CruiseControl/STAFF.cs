﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CruiseControl
{
    class STAFF
    {
        public int staff_id { get; set; }
        public string name { get; set; }
    }
}
