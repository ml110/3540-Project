﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CruiseControl
{
    class TABLE
    {
        public int table_id { get; set; }
        public int max_capacity { get; set; }
        public int ship_id { get; set; }
        public int area_id { get; set; }
    }
}
