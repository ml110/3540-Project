﻿namespace customerSignUp
{
    partial class Billing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label20 = new System.Windows.Forms.Label();
            this.labelInvoice = new System.Windows.Forms.Label();
            this.displayRes = new System.Windows.Forms.RichTextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnCalc = new System.Windows.Forms.Button();
            this.validationDateBirthGuest1 = new System.Windows.Forms.Label();
            this.dateBirthGuest1Input = new System.Windows.Forms.DateTimePicker();
            this.labelDateBirthGuest1 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lNameGuest1Input = new System.Windows.Forms.TextBox();
            this.labelLnameGuest1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.fNameGuest1Input = new System.Windows.Forms.TextBox();
            this.labelFnameGuest1 = new System.Windows.Forms.Label();
            this.labelGuest1 = new System.Windows.Forms.Label();
            this.horizontalGuest1 = new System.Windows.Forms.Label();
            this.validationLnameGuest1 = new System.Windows.Forms.Label();
            this.validationFnameGuest1 = new System.Windows.Forms.Label();
            this.validationFnameGuest2 = new System.Windows.Forms.Label();
            this.validationLnameGuest2 = new System.Windows.Forms.Label();
            this.validationDateBirthGuest2 = new System.Windows.Forms.Label();
            this.dateBirthGuest2Input = new System.Windows.Forms.DateTimePicker();
            this.labelDateBirthGuest2 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lNameGuest2Input = new System.Windows.Forms.TextBox();
            this.labelLnameGuest2 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.fNameGuest2Input = new System.Windows.Forms.TextBox();
            this.labelFnameGuest2 = new System.Windows.Forms.Label();
            this.labelGuest2 = new System.Windows.Forms.Label();
            this.horizontalGuest2 = new System.Windows.Forms.Label();
            this.validationFnameGuest3 = new System.Windows.Forms.Label();
            this.validationLnameGuest3 = new System.Windows.Forms.Label();
            this.validationDateBirthGuest3 = new System.Windows.Forms.Label();
            this.dateBirthGuest3Input = new System.Windows.Forms.DateTimePicker();
            this.labelDateBirthGuest3 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lNameGuest3Input = new System.Windows.Forms.TextBox();
            this.labelLnameGuest3 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.fNameGuest3Input = new System.Windows.Forms.TextBox();
            this.labelFnameGuest3 = new System.Windows.Forms.Label();
            this.labelGuest3 = new System.Windows.Forms.Label();
            this.horizontalGuest3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(833, 62);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(48, 15);
            this.label20.TabIndex = 74;
            this.label20.Text = "label11";
            // 
            // labelInvoice
            // 
            this.labelInvoice.AutoSize = true;
            this.labelInvoice.Font = new System.Drawing.Font("Palatino Linotype", 32F);
            this.labelInvoice.Location = new System.Drawing.Point(445, 335);
            this.labelInvoice.Name = "labelInvoice";
            this.labelInvoice.Size = new System.Drawing.Size(165, 58);
            this.labelInvoice.TabIndex = 76;
            this.labelInvoice.Text = "Invoice";
            // 
            // displayRes
            // 
            this.displayRes.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.displayRes.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.displayRes.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayRes.Location = new System.Drawing.Point(111, 417);
            this.displayRes.Name = "displayRes";
            this.displayRes.ReadOnly = true;
            this.displayRes.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.displayRes.Size = new System.Drawing.Size(638, 285);
            this.displayRes.TabIndex = 77;
            this.displayRes.Text = "";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.SteelBlue;
            this.btnExit.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(811, 560);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(162, 71);
            this.btnExit.TabIndex = 78;
            this.btnExit.Text = "EXIT";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnCalc
            // 
            this.btnCalc.BackColor = System.Drawing.Color.SteelBlue;
            this.btnCalc.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.ForeColor = System.Drawing.Color.White;
            this.btnCalc.Location = new System.Drawing.Point(811, 459);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(162, 71);
            this.btnCalc.TabIndex = 79;
            this.btnCalc.Text = "GENERATE INVOICE";
            this.btnCalc.UseVisualStyleBackColor = false;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click_1);
            // 
            // validationDateBirthGuest1
            // 
            this.validationDateBirthGuest1.AutoSize = true;
            this.validationDateBirthGuest1.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.validationDateBirthGuest1.Location = new System.Drawing.Point(828, 45);
            this.validationDateBirthGuest1.Margin = new System.Windows.Forms.Padding(0);
            this.validationDateBirthGuest1.Name = "validationDateBirthGuest1";
            this.validationDateBirthGuest1.Size = new System.Drawing.Size(0, 15);
            this.validationDateBirthGuest1.TabIndex = 109;
            // 
            // dateBirthGuest1Input
            // 
            this.dateBirthGuest1Input.CustomFormat = "MMMM dd yyyy";
            this.dateBirthGuest1Input.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateBirthGuest1Input.Location = new System.Drawing.Point(733, 68);
            this.dateBirthGuest1Input.Name = "dateBirthGuest1Input";
            this.dateBirthGuest1Input.Size = new System.Drawing.Size(244, 27);
            this.dateBirthGuest1Input.TabIndex = 108;
            this.dateBirthGuest1Input.Value = new System.DateTime(2016, 11, 5, 0, 0, 0, 0);
            // 
            // labelDateBirthGuest1
            // 
            this.labelDateBirthGuest1.AutoSize = true;
            this.labelDateBirthGuest1.Location = new System.Drawing.Point(729, 45);
            this.labelDateBirthGuest1.Name = "labelDateBirthGuest1";
            this.labelDateBirthGuest1.Size = new System.Drawing.Size(102, 20);
            this.labelDateBirthGuest1.TabIndex = 107;
            this.labelDateBirthGuest1.Text = "Date Of Birth";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(513, 47);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 15);
            this.label18.TabIndex = 106;
            // 
            // lNameGuest1Input
            // 
            this.lNameGuest1Input.BackColor = System.Drawing.Color.GhostWhite;
            this.lNameGuest1Input.ForeColor = System.Drawing.Color.Black;
            this.lNameGuest1Input.Location = new System.Drawing.Point(423, 69);
            this.lNameGuest1Input.Name = "lNameGuest1Input";
            this.lNameGuest1Input.Size = new System.Drawing.Size(244, 26);
            this.lNameGuest1Input.TabIndex = 105;
            // 
            // labelLnameGuest1
            // 
            this.labelLnameGuest1.AutoSize = true;
            this.labelLnameGuest1.Location = new System.Drawing.Point(419, 46);
            this.labelLnameGuest1.Name = "labelLnameGuest1";
            this.labelLnameGuest1.Size = new System.Drawing.Size(86, 20);
            this.labelLnameGuest1.TabIndex = 104;
            this.labelLnameGuest1.Text = "Last Name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(202, 46);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 15);
            this.label13.TabIndex = 103;
            // 
            // fNameGuest1Input
            // 
            this.fNameGuest1Input.BackColor = System.Drawing.Color.GhostWhite;
            this.fNameGuest1Input.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.fNameGuest1Input.ForeColor = System.Drawing.Color.Black;
            this.fNameGuest1Input.Location = new System.Drawing.Point(111, 69);
            this.fNameGuest1Input.Name = "fNameGuest1Input";
            this.fNameGuest1Input.Size = new System.Drawing.Size(244, 26);
            this.fNameGuest1Input.TabIndex = 102;
            // 
            // labelFnameGuest1
            // 
            this.labelFnameGuest1.AutoSize = true;
            this.labelFnameGuest1.Location = new System.Drawing.Point(107, 46);
            this.labelFnameGuest1.Name = "labelFnameGuest1";
            this.labelFnameGuest1.Size = new System.Drawing.Size(86, 20);
            this.labelFnameGuest1.TabIndex = 101;
            this.labelFnameGuest1.Text = "First Name";
            // 
            // labelGuest1
            // 
            this.labelGuest1.AutoSize = true;
            this.labelGuest1.Location = new System.Drawing.Point(50, 10);
            this.labelGuest1.Name = "labelGuest1";
            this.labelGuest1.Size = new System.Drawing.Size(66, 20);
            this.labelGuest1.TabIndex = 100;
            this.labelGuest1.Text = "Guest 1";
            // 
            // horizontalGuest1
            // 
            this.horizontalGuest1.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.horizontalGuest1.Location = new System.Drawing.Point(140, 7);
            this.horizontalGuest1.Name = "horizontalGuest1";
            this.horizontalGuest1.Size = new System.Drawing.Size(820, 23);
            this.horizontalGuest1.TabIndex = 99;
            this.horizontalGuest1.Text = "_________________________________________________________________________________" +
    "______";
            // 
            // validationLnameGuest1
            // 
            this.validationLnameGuest1.AutoSize = true;
            this.validationLnameGuest1.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.validationLnameGuest1.Location = new System.Drawing.Point(502, 45);
            this.validationLnameGuest1.Margin = new System.Windows.Forms.Padding(0);
            this.validationLnameGuest1.Name = "validationLnameGuest1";
            this.validationLnameGuest1.Size = new System.Drawing.Size(0, 15);
            this.validationLnameGuest1.TabIndex = 110;
            // 
            // validationFnameGuest1
            // 
            this.validationFnameGuest1.AutoSize = true;
            this.validationFnameGuest1.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.validationFnameGuest1.Location = new System.Drawing.Point(191, 45);
            this.validationFnameGuest1.Margin = new System.Windows.Forms.Padding(0);
            this.validationFnameGuest1.Name = "validationFnameGuest1";
            this.validationFnameGuest1.Size = new System.Drawing.Size(0, 15);
            this.validationFnameGuest1.TabIndex = 111;
            // 
            // validationFnameGuest2
            // 
            this.validationFnameGuest2.AutoSize = true;
            this.validationFnameGuest2.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.validationFnameGuest2.Location = new System.Drawing.Point(191, 151);
            this.validationFnameGuest2.Margin = new System.Windows.Forms.Padding(0);
            this.validationFnameGuest2.Name = "validationFnameGuest2";
            this.validationFnameGuest2.Size = new System.Drawing.Size(0, 15);
            this.validationFnameGuest2.TabIndex = 124;
            // 
            // validationLnameGuest2
            // 
            this.validationLnameGuest2.AutoSize = true;
            this.validationLnameGuest2.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.validationLnameGuest2.Location = new System.Drawing.Point(502, 151);
            this.validationLnameGuest2.Margin = new System.Windows.Forms.Padding(0);
            this.validationLnameGuest2.Name = "validationLnameGuest2";
            this.validationLnameGuest2.Size = new System.Drawing.Size(0, 15);
            this.validationLnameGuest2.TabIndex = 123;
            // 
            // validationDateBirthGuest2
            // 
            this.validationDateBirthGuest2.AutoSize = true;
            this.validationDateBirthGuest2.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.validationDateBirthGuest2.Location = new System.Drawing.Point(828, 151);
            this.validationDateBirthGuest2.Margin = new System.Windows.Forms.Padding(0);
            this.validationDateBirthGuest2.Name = "validationDateBirthGuest2";
            this.validationDateBirthGuest2.Size = new System.Drawing.Size(0, 15);
            this.validationDateBirthGuest2.TabIndex = 122;
            // 
            // dateBirthGuest2Input
            // 
            this.dateBirthGuest2Input.CustomFormat = "MMMM dd yyyy";
            this.dateBirthGuest2Input.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateBirthGuest2Input.Location = new System.Drawing.Point(733, 174);
            this.dateBirthGuest2Input.Name = "dateBirthGuest2Input";
            this.dateBirthGuest2Input.Size = new System.Drawing.Size(244, 27);
            this.dateBirthGuest2Input.TabIndex = 121;
            this.dateBirthGuest2Input.Value = new System.DateTime(2016, 11, 5, 0, 0, 0, 0);
            // 
            // labelDateBirthGuest2
            // 
            this.labelDateBirthGuest2.AutoSize = true;
            this.labelDateBirthGuest2.Location = new System.Drawing.Point(729, 151);
            this.labelDateBirthGuest2.Name = "labelDateBirthGuest2";
            this.labelDateBirthGuest2.Size = new System.Drawing.Size(102, 20);
            this.labelDateBirthGuest2.TabIndex = 120;
            this.labelDateBirthGuest2.Text = "Date Of Birth";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(513, 153);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(0, 15);
            this.label21.TabIndex = 119;
            // 
            // lNameGuest2Input
            // 
            this.lNameGuest2Input.BackColor = System.Drawing.Color.GhostWhite;
            this.lNameGuest2Input.ForeColor = System.Drawing.Color.Black;
            this.lNameGuest2Input.Location = new System.Drawing.Point(423, 175);
            this.lNameGuest2Input.Name = "lNameGuest2Input";
            this.lNameGuest2Input.Size = new System.Drawing.Size(244, 26);
            this.lNameGuest2Input.TabIndex = 118;
            // 
            // labelLnameGuest2
            // 
            this.labelLnameGuest2.AutoSize = true;
            this.labelLnameGuest2.Location = new System.Drawing.Point(419, 152);
            this.labelLnameGuest2.Name = "labelLnameGuest2";
            this.labelLnameGuest2.Size = new System.Drawing.Size(86, 20);
            this.labelLnameGuest2.TabIndex = 117;
            this.labelLnameGuest2.Text = "Last Name";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(202, 152);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(0, 15);
            this.label25.TabIndex = 116;
            // 
            // fNameGuest2Input
            // 
            this.fNameGuest2Input.BackColor = System.Drawing.Color.GhostWhite;
            this.fNameGuest2Input.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.fNameGuest2Input.ForeColor = System.Drawing.Color.Black;
            this.fNameGuest2Input.Location = new System.Drawing.Point(111, 175);
            this.fNameGuest2Input.Name = "fNameGuest2Input";
            this.fNameGuest2Input.Size = new System.Drawing.Size(244, 26);
            this.fNameGuest2Input.TabIndex = 115;
            // 
            // labelFnameGuest2
            // 
            this.labelFnameGuest2.AutoSize = true;
            this.labelFnameGuest2.Location = new System.Drawing.Point(107, 152);
            this.labelFnameGuest2.Name = "labelFnameGuest2";
            this.labelFnameGuest2.Size = new System.Drawing.Size(86, 20);
            this.labelFnameGuest2.TabIndex = 114;
            this.labelFnameGuest2.Text = "First Name";
            // 
            // labelGuest2
            // 
            this.labelGuest2.AutoSize = true;
            this.labelGuest2.Location = new System.Drawing.Point(50, 116);
            this.labelGuest2.Name = "labelGuest2";
            this.labelGuest2.Size = new System.Drawing.Size(66, 20);
            this.labelGuest2.TabIndex = 113;
            this.labelGuest2.Text = "Guest 2";
            // 
            // horizontalGuest2
            // 
            this.horizontalGuest2.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.horizontalGuest2.Location = new System.Drawing.Point(140, 113);
            this.horizontalGuest2.Name = "horizontalGuest2";
            this.horizontalGuest2.Size = new System.Drawing.Size(820, 23);
            this.horizontalGuest2.TabIndex = 112;
            this.horizontalGuest2.Text = "_________________________________________________________________________________" +
    "______";
            // 
            // validationFnameGuest3
            // 
            this.validationFnameGuest3.AutoSize = true;
            this.validationFnameGuest3.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.validationFnameGuest3.Location = new System.Drawing.Point(191, 258);
            this.validationFnameGuest3.Margin = new System.Windows.Forms.Padding(0);
            this.validationFnameGuest3.Name = "validationFnameGuest3";
            this.validationFnameGuest3.Size = new System.Drawing.Size(0, 15);
            this.validationFnameGuest3.TabIndex = 137;
            // 
            // validationLnameGuest3
            // 
            this.validationLnameGuest3.AutoSize = true;
            this.validationLnameGuest3.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.validationLnameGuest3.Location = new System.Drawing.Point(502, 258);
            this.validationLnameGuest3.Margin = new System.Windows.Forms.Padding(0);
            this.validationLnameGuest3.Name = "validationLnameGuest3";
            this.validationLnameGuest3.Size = new System.Drawing.Size(0, 15);
            this.validationLnameGuest3.TabIndex = 136;
            // 
            // validationDateBirthGuest3
            // 
            this.validationDateBirthGuest3.AutoSize = true;
            this.validationDateBirthGuest3.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.validationDateBirthGuest3.Location = new System.Drawing.Point(828, 258);
            this.validationDateBirthGuest3.Margin = new System.Windows.Forms.Padding(0);
            this.validationDateBirthGuest3.Name = "validationDateBirthGuest3";
            this.validationDateBirthGuest3.Size = new System.Drawing.Size(0, 15);
            this.validationDateBirthGuest3.TabIndex = 135;
            // 
            // dateBirthGuest3Input
            // 
            this.dateBirthGuest3Input.CustomFormat = "MMMM dd yyyy";
            this.dateBirthGuest3Input.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateBirthGuest3Input.Location = new System.Drawing.Point(733, 281);
            this.dateBirthGuest3Input.Name = "dateBirthGuest3Input";
            this.dateBirthGuest3Input.Size = new System.Drawing.Size(244, 27);
            this.dateBirthGuest3Input.TabIndex = 134;
            this.dateBirthGuest3Input.Value = new System.DateTime(2016, 11, 5, 0, 0, 0, 0);
            // 
            // labelDateBirthGuest3
            // 
            this.labelDateBirthGuest3.AutoSize = true;
            this.labelDateBirthGuest3.Location = new System.Drawing.Point(729, 258);
            this.labelDateBirthGuest3.Name = "labelDateBirthGuest3";
            this.labelDateBirthGuest3.Size = new System.Drawing.Size(102, 20);
            this.labelDateBirthGuest3.TabIndex = 133;
            this.labelDateBirthGuest3.Text = "Date Of Birth";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(513, 260);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(0, 15);
            this.label19.TabIndex = 132;
            // 
            // lNameGuest3Input
            // 
            this.lNameGuest3Input.BackColor = System.Drawing.Color.GhostWhite;
            this.lNameGuest3Input.ForeColor = System.Drawing.Color.Black;
            this.lNameGuest3Input.Location = new System.Drawing.Point(423, 282);
            this.lNameGuest3Input.Name = "lNameGuest3Input";
            this.lNameGuest3Input.Size = new System.Drawing.Size(244, 26);
            this.lNameGuest3Input.TabIndex = 131;
            // 
            // labelLnameGuest3
            // 
            this.labelLnameGuest3.AutoSize = true;
            this.labelLnameGuest3.Location = new System.Drawing.Point(419, 259);
            this.labelLnameGuest3.Name = "labelLnameGuest3";
            this.labelLnameGuest3.Size = new System.Drawing.Size(86, 20);
            this.labelLnameGuest3.TabIndex = 130;
            this.labelLnameGuest3.Text = "Last Name";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(202, 259);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(0, 15);
            this.label23.TabIndex = 129;
            // 
            // fNameGuest3Input
            // 
            this.fNameGuest3Input.BackColor = System.Drawing.Color.GhostWhite;
            this.fNameGuest3Input.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.fNameGuest3Input.ForeColor = System.Drawing.Color.Black;
            this.fNameGuest3Input.Location = new System.Drawing.Point(111, 282);
            this.fNameGuest3Input.Name = "fNameGuest3Input";
            this.fNameGuest3Input.Size = new System.Drawing.Size(244, 26);
            this.fNameGuest3Input.TabIndex = 128;
            // 
            // labelFnameGuest3
            // 
            this.labelFnameGuest3.AutoSize = true;
            this.labelFnameGuest3.Location = new System.Drawing.Point(107, 259);
            this.labelFnameGuest3.Name = "labelFnameGuest3";
            this.labelFnameGuest3.Size = new System.Drawing.Size(86, 20);
            this.labelFnameGuest3.TabIndex = 127;
            this.labelFnameGuest3.Text = "First Name";
            // 
            // labelGuest3
            // 
            this.labelGuest3.AutoSize = true;
            this.labelGuest3.Location = new System.Drawing.Point(50, 223);
            this.labelGuest3.Name = "labelGuest3";
            this.labelGuest3.Size = new System.Drawing.Size(66, 20);
            this.labelGuest3.TabIndex = 126;
            this.labelGuest3.Text = "Guest 3";
            // 
            // horizontalGuest3
            // 
            this.horizontalGuest3.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.horizontalGuest3.Location = new System.Drawing.Point(140, 220);
            this.horizontalGuest3.Name = "horizontalGuest3";
            this.horizontalGuest3.Size = new System.Drawing.Size(820, 23);
            this.horizontalGuest3.TabIndex = 125;
            this.horizontalGuest3.Text = "_________________________________________________________________________________" +
    "______";
            // 
            // Billing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1036, 744);
            this.Controls.Add(this.validationFnameGuest3);
            this.Controls.Add(this.validationLnameGuest3);
            this.Controls.Add(this.validationDateBirthGuest3);
            this.Controls.Add(this.dateBirthGuest3Input);
            this.Controls.Add(this.labelDateBirthGuest3);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.lNameGuest3Input);
            this.Controls.Add(this.labelLnameGuest3);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.fNameGuest3Input);
            this.Controls.Add(this.labelFnameGuest3);
            this.Controls.Add(this.labelGuest3);
            this.Controls.Add(this.horizontalGuest3);
            this.Controls.Add(this.validationFnameGuest2);
            this.Controls.Add(this.validationLnameGuest2);
            this.Controls.Add(this.validationDateBirthGuest2);
            this.Controls.Add(this.dateBirthGuest2Input);
            this.Controls.Add(this.labelDateBirthGuest2);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.lNameGuest2Input);
            this.Controls.Add(this.labelLnameGuest2);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.fNameGuest2Input);
            this.Controls.Add(this.labelFnameGuest2);
            this.Controls.Add(this.labelGuest2);
            this.Controls.Add(this.horizontalGuest2);
            this.Controls.Add(this.validationFnameGuest1);
            this.Controls.Add(this.validationLnameGuest1);
            this.Controls.Add(this.validationDateBirthGuest1);
            this.Controls.Add(this.dateBirthGuest1Input);
            this.Controls.Add(this.labelDateBirthGuest1);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.lNameGuest1Input);
            this.Controls.Add(this.labelLnameGuest1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.fNameGuest1Input);
            this.Controls.Add(this.labelFnameGuest1);
            this.Controls.Add(this.labelGuest1);
            this.Controls.Add(this.horizontalGuest1);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.displayRes);
            this.Controls.Add(this.labelInvoice);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Billing";
            this.ShowIcon = false;
            this.Load += new System.EventHandler(this.Billing_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelDateOfBirthGuest1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label labelInvoice;
        private System.Windows.Forms.RichTextBox displayRes;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label validationDateBirthGuest1;
        private System.Windows.Forms.DateTimePicker dateBirthGuest1Input;
        private System.Windows.Forms.Label labelDateBirthGuest1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox lNameGuest1Input;
        private System.Windows.Forms.Label labelLnameGuest1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox fNameGuest1Input;
        private System.Windows.Forms.Label labelFnameGuest1;
        private System.Windows.Forms.Label labelGuest1;
        private System.Windows.Forms.Label horizontalGuest1;
        private System.Windows.Forms.Label validationLnameGuest1;
        private System.Windows.Forms.Label validationFnameGuest1;
        private System.Windows.Forms.Label validationFnameGuest2;
        private System.Windows.Forms.Label validationLnameGuest2;
        private System.Windows.Forms.Label validationDateBirthGuest2;
        private System.Windows.Forms.DateTimePicker dateBirthGuest2Input;
        private System.Windows.Forms.Label labelDateBirthGuest2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox lNameGuest2Input;
        private System.Windows.Forms.Label labelLnameGuest2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox fNameGuest2Input;
        private System.Windows.Forms.Label labelFnameGuest2;
        private System.Windows.Forms.Label labelGuest2;
        private System.Windows.Forms.Label horizontalGuest2;
        private System.Windows.Forms.Label validationFnameGuest3;
        private System.Windows.Forms.Label validationLnameGuest3;
        private System.Windows.Forms.Label validationDateBirthGuest3;
        private System.Windows.Forms.DateTimePicker dateBirthGuest3Input;
        private System.Windows.Forms.Label labelDateBirthGuest3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox lNameGuest3Input;
        private System.Windows.Forms.Label labelLnameGuest3;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox fNameGuest3Input;
        private System.Windows.Forms.Label labelFnameGuest3;
        private System.Windows.Forms.Label labelGuest3;
        private System.Windows.Forms.Label horizontalGuest3;
    }
}